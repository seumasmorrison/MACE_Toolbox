function trm=vels(ffreqs,dirs,wns,z,depth)

trm=(-i*ffreqs)*ones(size(dirs));